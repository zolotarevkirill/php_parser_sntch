<?php

include('phpquery.php');

$products = [];

$catalog_url = 'https://www.santech.ru'.$_GET['secion_id'];

$contents = file_get_contents( $catalog_url,false, stream_context_create( array( 'ssl' => array( 'verify_peer' => false, 'verify_peer_name' => false ) ) ) );

$products= [];

$document = phpQuery::newDocument($contents);

$title = $document->find('.products__name');


foreach ($title as $el) {
	array_push($products, $el->textContent);
}


$page = 1;
$max_page = 30;


while ($page < $max_page) {
	$page = $page + 1;
	$catalog_url = 'https://www.santech.ru'.$_GET['secion_id'];
	$document = phpQuery::newDocument($contents);

	$title = $document->find('.products__name');


	if(strlen($title))
	{
	  foreach ($title as $el) {
		array_push($products, $el->textContent);
	  }
	}
	else
	{
		echo "Last page: ".$page."<br/>";
		echo $catalog_url;
		echo "<br/>";
		var_dump(is_array($title));
		echo "<br/>";
		echo count($title);
		echo "<br/>";
		echo $title[0]->textContent;
	   	break;
	}
}

echo "<pre>";
var_dump($products);
  



