<?
echo "Это парсер сайта https://www.santech.ru/ от 28.10.2019";
echo "<br/>";
echo "<a href='category.php'>Категории</a>";